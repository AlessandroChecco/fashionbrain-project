This would have the standard template (top_section, multiple inputs/outputs and bottom_section).
See fashwell.csv for the html snippets of the inputs and outputs.
See top_section.html and bottom_section.html for the other sections.

example.html is a page in which I put some css and put all output fragments together.

Feel free to use src folder if you need to access the raw data.


Add coordinates (both ways)