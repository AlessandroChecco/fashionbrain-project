This will have
top_section -> pure html (no js) coming soon
three inputs with only text (a title), the corresponding output will be pure html (no js) with only html and images
bottom_section -> only html with links to local files

input1-3.html and ouput1-3.html contain the input and output, I put a css in the output to make the image fit (but you might want to remove that there).

See src for raw data (shouldn't be needed)